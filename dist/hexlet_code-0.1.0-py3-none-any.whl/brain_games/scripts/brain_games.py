#!/usr/bin/env python
def main():

    if __name__ == '__main__':

        main()

print('Welcome to the Brain Games!')
